import './App.css'
import FirstApp from './FirstApp'


const App = ()=>{
  return(
  <>
  <h1>Hola Mundo</h1>
  <h2>Bienvenido</h2>
  <FirstApp/>
  </> 
  )
}

export default App
